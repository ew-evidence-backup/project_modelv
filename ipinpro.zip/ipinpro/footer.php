<div class="clearfix"></div>

<?php wp_footer(); ?>

</body>
</html>